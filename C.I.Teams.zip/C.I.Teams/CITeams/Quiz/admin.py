from django.contrib import admin
from Quiz import models

# Register your models here.

admin.site.register(models.Quiz)
admin.site.register(models.QuizQuestion)
admin.site.register(models.QuizOption)
admin.site.register(models.QuizQuestionSolution)
admin.site.register(models.QuizResponse)
admin.site.register(models.QuizResponseAnswer)

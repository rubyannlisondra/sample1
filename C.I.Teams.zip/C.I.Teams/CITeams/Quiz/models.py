from django.db import models
from User.models import User, Student
from Classroom.models import Classroom
from django.utils.translation import gettext_lazy as _


class Quiz(models.Model):
    quizID = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=255)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="quizzes")
    dueDate = models.DateTimeField()
    closeDate = models.DateTimeField(null=True, default=None)
    classroom = models.ForeignKey(
        Classroom, on_delete=models.CASCADE, related_name="quizzes"
    )


class QuizQuestion(models.Model):
    class QuizQuestionType(models.TextChoices):
        MULTIPLE_CHOICE = "MC", _("Multiple Choice")
        IDENTIFICATION = "I", _("Identification")
        CHECKBOX = "C", _("Checkbox")

    quizQuestionID = models.BigAutoField(primary_key=True)
    quizType = models.CharField(max_length=2, choices=QuizQuestionType.choices)
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name="questions")
    order = models.SmallIntegerField()


class QuizOption(models.Model):
    quizOptionID = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=200)
    order = models.PositiveSmallIntegerField()
    quizQuestion = models.ForeignKey(
        QuizQuestion,
        on_delete=models.CASCADE,
        related_name="quiz_options",
    )


class QuizQuestionSolution(models.Model):
    QuizQuestionSolutionID = models.BigAutoField(primary_key=True)
    response = models.TextField(null=True, blank=True)
    quizOptions = models.ManyToManyField(
        QuizOption, related_name="quiz_question_solutions"
    )
    quizQuestion = models.ForeignKey(
        QuizQuestion,
        on_delete=models.CASCADE,
        related_name="quiz_question_solutions",
    )


class QuizResponse(models.Model):
    quizResponseID = models.BigAutoField(primary_key=True)
    student = models.ForeignKey(
        Student, on_delete=models.CASCADE, related_name="quiz_responses"
    )
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE, related_name="responses")


class QuizResponseAnswer(models.Model):
    quizResponseAnswerID = models.BigAutoField(primary_key=True)
    response = models.TextField(null=True, blank=True)
    is_correct = models.BooleanField(default=False, null=True)
    quizOptions = models.ManyToManyField(
        QuizOption, related_name="quiz_response_answers"
    )
    quizResponse = models.ForeignKey(
        QuizResponse,
        on_delete=models.CASCADE,
        related_name="answers",
    )
    quizQuestion = models.ForeignKey(
        QuizQuestion, on_delete=models.CASCADE, related_name="response_answers"
    )

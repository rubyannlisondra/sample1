from django.db import models
from User.models import User

# Create your models here.

class ChatRoom(models.Model):
    chatRoomID = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)

class Message(models.Model):
    messageID = models.AutoField(primary_key=True)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    chatroom = models.ForeignKey(ChatRoom, on_delete=models.CASCADE)

class ChatRoomUser(models.Model):
    chatRoomUserID = models.AutoField(primary_key=True)
    position = models.CharField(max_length=100)
    chatRoom = models.ForeignKey(ChatRoom, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

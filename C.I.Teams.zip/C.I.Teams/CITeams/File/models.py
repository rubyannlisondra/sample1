from django.db import models
from Classroom.models import Classroom, Post
from Chat.models import Message

# Create your models here.


class File(models.Model):
    fileID = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    size = models.BigIntegerField()
    timestamp = models.DateTimeField(auto_now_add=True)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, null=True)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, null=True)
    message = models.ForeignKey(Message, on_delete=models.CASCADE, null=True)


from django.db import models

# Create your models here.

class Classroom(models.Model):
    classID = models.AutoField(primary_key=True)
    className = models.CharField(max_length=25)

class Post(models.Model):
    postID = models.AutoField(primary_key=True)
    content = models.CharField(max_length=4000)
    timestamp = models.DateTimeField(auto_now_add=True)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE)


class Comment(models.Model):
    commentID = models.AutoField(primary_key=True)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    content = models.CharField(max_length=4000)
    timestamp = models.DateTimeField(auto_now_add=True)

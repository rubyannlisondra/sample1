from django.contrib import admin
from .models import Admin, Student

# Register your models here.
admin.site.register(Admin)
admin.site.register(Student)